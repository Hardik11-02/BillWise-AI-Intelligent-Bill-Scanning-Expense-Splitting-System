# BillSplit AI

A Streamlit application that reads a bill photograph using OCR and calculates each person's share.

## Run

```powershell
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Tesseract OCR must be installed on Windows. The application automatically checks the standard installation path:
`C:\Program Files\Tesseract-OCR\tesseract.exe`

## Features

- Bill photograph upload
- OCR item and price extraction
- Editable bill items
- Multiple people
- Item-level sharing
- Automatic split calculation
- CSV export
- OCR text preview
