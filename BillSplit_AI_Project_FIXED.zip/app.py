import re
import os
import shutil
import pandas as pd
import streamlit as st
from PIL import Image, ImageOps, ImageFilter
import pytesseract

st.set_page_config(page_title="BillSplit AI", page_icon="🧾", layout="wide")

def configure_tesseract():
    candidates = [
        shutil.which("tesseract"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
    ]
    for path in candidates:
        if path and os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            return True
    return False

def preprocess_image(image):
    image = ImageOps.exif_transpose(image).convert("L")
    image.thumbnail((2400, 2400))
    image = ImageOps.autocontrast(image)
    return image.filter(ImageFilter.SHARPEN)

def extract_text(image):
    return pytesseract.image_to_string(preprocess_image(image), config="--psm 6")

def parse_items(text):
    patterns = [
        re.compile(r"(.+?)\s+(?:₹|Rs\.?|INR)?\s*(\d+(?:[.,]\d{1,2})?)\s*$", re.I),
        re.compile(r"(.+?)\s+(\d+(?:[.,]\d{1,2})?)\s*(?:₹|Rs\.?|INR)\s*$", re.I)
    ]
    ignored = {
        "total", "subtotal", "tax", "gst", "cgst", "sgst", "discount",
        "change", "cash", "card", "upi", "amount", "balance", "round off"
    }
    result = []
    seen = set()
    for raw in text.splitlines():
        line = re.sub(r"\s+", " ", raw).strip()
        if len(line) < 3:
            continue
        match = next((p.match(line) for p in patterns if p.match(line)), None)
        if not match:
            continue
        name = match.group(1).strip(" .:-")
        try:
            price = float(match.group(2).replace(",", "."))
        except ValueError:
            continue
        if not name or price <= 0 or price > 100000:
            continue
        if any(word in name.lower() for word in ignored):
            continue
        key = (name.lower(), round(price, 2))
        if key not in seen:
            seen.add(key)
            result.append({"Item": name, "Price": price})
    return result

def calculate_shares(df, people):
    totals = {person: 0.0 for person in people}
    for _, row in df.iterrows():
        selected = row["Shared By"]
        if selected:
            share = float(row["Price"]) / len(selected)
            for person in selected:
                totals[person] += share
    return totals

if "bill_items" not in st.session_state:
    st.session_state["bill_items"] = []

if "ocr_text" not in st.session_state:
    st.session_state["ocr_text"] = ""

st.title("🧾 BillSplit AI")
st.write("Upload a bill photo, extract items and prices, assign people, and calculate each person's share.")

if not configure_tesseract():
    st.error("Tesseract OCR is not installed or not available.")
    st.info(r"Expected location: C:\Program Files\Tesseract-OCR\tesseract.exe")
    st.stop()

col1, col2 = st.columns([1, 1])

with col1:
    uploaded = st.file_uploader("Upload bill photograph", type=["png", "jpg", "jpeg", "webp"])
    if uploaded:
        image = Image.open(uploaded)
        st.image(image, caption="Uploaded Bill", use_container_width=True)
        if st.button("Extract Bill Items", type="primary", use_container_width=True):
            with st.spinner("Reading bill..."):
                text = extract_text(image)
                detected = parse_items(text)
                st.session_state["bill_items"] = detected
                st.session_state["ocr_text"] = text
            if detected:
                st.success(f"Detected {len(detected)} item(s).")
            else:
                st.warning("No item-price pairs were detected. Add items manually below.")

with col2:
    st.subheader("People")
    people_text = st.text_input("Enter names separated by commas", "Hardik, Friend 1")
    people = [x.strip() for x in people_text.split(",") if x.strip()]

st.divider()
st.subheader("Bill Items")

if st.session_state["bill_items"]:
    initial_df = pd.DataFrame(st.session_state["bill_items"])
else:
    initial_df = pd.DataFrame({"Item": [""], "Price": [0.0]})

edited_df = st.data_editor(
    initial_df,
    num_rows="dynamic",
    use_container_width=True,
    column_config={
        "Item": st.column_config.TextColumn("Item"),
        "Price": st.column_config.NumberColumn("Price", min_value=0.0, format="₹ %.2f")
    },
    key="bill_editor"
)

if people:
    assignments = []
    for i, row in edited_df.iterrows():
        item_name = str(row.get("Item", "")).strip()
        price = float(row.get("Price", 0) or 0)
        if not item_name or price <= 0:
            assignments.append([])
            continue
        assignments.append(
            st.multiselect(
                f"Who had {item_name}?",
                people,
                default=people,
                key=f"assign_{i}"
            )
        )

    working_df = edited_df.copy()
    working_df["Shared By"] = assignments
    totals = calculate_shares(working_df, people)

    st.divider()
    st.subheader("Final Split")

    cols = st.columns(max(1, min(len(people), 4)))
    for i, person in enumerate(people):
        with cols[i % len(cols)]:
            st.metric(person, f"₹ {totals[person]:.2f}")

    grand_total = sum(totals.values())
    st.write(f"**Calculated Total: ₹ {grand_total:.2f}**")

    result = pd.DataFrame({
        "Person": list(totals.keys()),
        "Amount": [round(value, 2) for value in totals.values()]
    })
    st.dataframe(result, use_container_width=True, hide_index=True)

    st.download_button(
        "Download Split as CSV",
        result.to_csv(index=False).encode("utf-8"),
        "bill_split.csv",
        "text/csv",
        use_container_width=True
    )
else:
    st.warning("Add at least one person's name to continue.")

with st.expander("View OCR Text"):
    st.text(st.session_state["ocr_text"] or "Upload a bill and click Extract Bill Items.")
